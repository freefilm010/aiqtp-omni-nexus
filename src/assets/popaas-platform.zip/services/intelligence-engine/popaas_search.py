from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from qdrant_client import QdrantClient
from qdrant_client.http import models as qmodels

from opensearchpy import OpenSearch

def qdrant_client() -> Optional[QdrantClient]:
    url = os.getenv("QDRANT_URL")
    if not url:
        return None
    api_key = os.getenv("QDRANT_API_KEY") or None
    return QdrantClient(url=url, api_key=api_key)

def opensearch_client() -> Optional[OpenSearch]:
    url = os.getenv("OPENSEARCH_URL")
    if not url:
        return None
    user = os.getenv("OPENSEARCH_USERNAME") or None
    pwd = os.getenv("OPENSEARCH_PASSWORD") or None
    if user and pwd:
        return OpenSearch(hosts=[url], http_auth=(user, pwd), verify_certs=False)
    return OpenSearch(hosts=[url], verify_certs=False)

def ensure_qdrant_collection(name: str, vector_size: int = 128) -> None:
    qc = qdrant_client()
    if not qc:
        return
    try:
        qc.get_collection(name)
    except Exception:
        qc.create_collection(
            collection_name=name,
            vectors_config=qmodels.VectorParams(size=vector_size, distance=qmodels.Distance.COSINE),
        )

def upsert_vectors(collection: str, points: List[Dict[str, Any]]) -> None:
    qc = qdrant_client()
    if not qc:
        return
    ensure_qdrant_collection(collection)
    qc.upsert(
        collection_name=collection,
        points=[
            qmodels.PointStruct(
                id=p["id"],
                vector=p["vector"],
                payload=p.get("payload") or {},
            )
            for p in points
        ],
    )

def search_vectors(collection: str, vector: List[float], limit: int = 10) -> List[Dict[str, Any]]:
    qc = qdrant_client()
    if not qc:
        return []
    ensure_qdrant_collection(collection)
    hits = qc.search(collection_name=collection, query_vector=vector, limit=limit)
    return [{"id": h.id, "score": h.score, "payload": h.payload} for h in hits]

def index_document(index: str, doc_id: str, body: Dict[str, Any]) -> None:
    oc = opensearch_client()
    if not oc:
        return
    oc.index(index=index, id=doc_id, body=body, refresh=True)

def text_search(index: str, query: str, size: int = 10) -> List[Dict[str, Any]]:
    oc = opensearch_client()
    if not oc:
        return []
    resp = oc.search(index=index, body={"query": {"multi_match": {"query": query, "fields": ["*"]}}, "size": size})
    hits = resp.get("hits", {}).get("hits", [])
    return [{"id": h.get("_id"), "score": h.get("_score"), "source": h.get("_source")} for h in hits]
