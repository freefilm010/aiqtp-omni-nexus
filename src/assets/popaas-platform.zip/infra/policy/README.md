# Policy-as-Code (OPA)

POPaaS uses Open Policy Agent (OPA) for optional centralized authorization checks.

## Concepts
- Policies live in `infra/policy/policies/`
- Services can call OPA with input JSON and receive allow/deny + reasons.

## Start OPA locally
`docker compose -f docker-compose.policy.yml up -d`

## Example
- `policies/rbac.rego` enforces:
  - only `role == "admin"` can access `/admin/*`
  - org-scoped access for `/api/*` when `org_id` matches

Integrate gradually; keep service-local RBAC as the primary enforcement.
