package popaas.rbac

default allow = false

# input example:
# {
#   "path": "/admin/users",
#   "method": "GET",
#   "user": {"id":"u1","role":"admin","org_id":"o1"},
#   "resource": {"org_id":"o1"}
# }

allow {
  startswith(input.path, "/admin")
  input.user.role == "admin"
}

allow {
  startswith(input.path, "/api")
  input.user.org_id == input.resource.org_id
}

deny_reason[msg] {
  not allow
  msg := "request denied by policy"
}
