FROM qdrant/qdrant:v1.10.1
