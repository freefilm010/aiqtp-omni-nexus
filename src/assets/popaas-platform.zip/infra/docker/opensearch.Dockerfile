FROM opensearchproject/opensearch:2.17.1
ENV discovery.type=single-node
ENV plugins.security.disabled=true
