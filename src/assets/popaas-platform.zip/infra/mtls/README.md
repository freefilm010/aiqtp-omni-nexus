# Service-to-service mTLS (optional)

This directory provides a **reference implementation** for mTLS between POPaaS services using:
- `step-ca` as an internal certificate authority
- `envoy` as a sidecar proxy enforcing mutual TLS

## Why optional?
Full mTLS is powerful but increases operational complexity. POPaaS supports:
- baseline TLS at ingress
- zero-trust auth with JWT + service tokens
- **optional** mTLS for regulated/defense-grade environments

## Local run (example)
`docker compose -f docker-compose.mtls.example.yml up -d`

This launches:
- step-ca
- an envoy front proxy
- an example service wired through envoy

To extend:
- add an envoy sidecar per service
- issue certs per workload identity
- rotate certs automatically

See `infra/mtls/envoy/` for configs.
