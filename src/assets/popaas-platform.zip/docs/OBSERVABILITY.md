# Observability (Option B)

POPaaS ships with an OpenTelemetry-based observability stack that is safe, modular, and fully self-hostable.

## Components
- OpenTelemetry Collector (OTLP gRPC/HTTP receivers)
- Prometheus (metrics)
- Grafana (dashboards)
- Loki (logs)

## Local run
1. Start core infra:
   - `docker compose -f docker-compose.optionB.yml up -d`
2. Start observability:
   - `docker compose -f docker-compose.observability.yml up -d`
3. Set env vars for each service:
   - `OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317`
   - `OTEL_SERVICE_NAME=<service-name>`

Grafana:
- http://localhost:3001 (anonymous viewer enabled for local dev)

## Production
On Render, run these as private docker services or use a managed observability provider.


## Added in v1.4
- Tempo for trace storage/query
- Promtail for optional container/system log shipping
