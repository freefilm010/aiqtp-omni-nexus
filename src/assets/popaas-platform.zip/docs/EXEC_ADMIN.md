# Executive Admin bootstrap

Set these environment variables in production:

- POPAAS_EXEC_ADMIN_EMAIL=1drrey@gmail.com
- POPAAS_EXEC_ADMIN_EMAIL_2=1drrey@duck.com
- POPAAS_BOOTSTRAP_TOKEN=<one-time token>

First login:
1. Sign in with one of the exec emails.
2. Provide the bootstrap token when prompted.
3. Token is burned and stored in the audit log.

Recommendation:
- Require 2FA at the IdP level if using SSO
- Rotate secrets quarterly
