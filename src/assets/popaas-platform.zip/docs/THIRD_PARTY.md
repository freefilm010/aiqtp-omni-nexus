# Third‑party open-source components

POPaaS is private/proprietary, but uses open-source dependencies under their licenses.

Core infra:
- Postgres (PostgreSQL License)
- Redis (BSD-3-Clause)
- Qdrant (Apache-2.0)
- OpenSearch (Apache-2.0)

AI/ML:
- ONNX Runtime (MIT)
- OpenCV (Apache-2.0) *(optional module)*
- Ultralytics YOLO (AGPL-3.0 / commercial dual-license) *(optional — only enable if you accept AGPL or have a commercial license)*

Observability/Security:
- OpenTelemetry (Apache-2.0)
- Trivy (Apache-2.0)

See each component's upstream repo for full license text.
