# Local deployment (Option B)

## Requirements
- Docker Desktop
- Node 18+
- Python 3.11+

## Start infra
`docker compose -f docker-compose.optionB.yml up -d`

## Configure env
Copy `.env.example` to `.env` and set:
- QDRANT_URL
- OPENSEARCH_URL
- JWT secrets, etc.

## Run services
Each service folder includes a README (or see root README).


## Observability
`docker compose -f docker-compose.observability.yml up -d`
See `docs/OBSERVABILITY.md`.


## Policy engine (OPA)
`docker compose -f docker-compose.policy.yml up -d`


## Optional mTLS (advanced)
See `infra/mtls/README.md`.
