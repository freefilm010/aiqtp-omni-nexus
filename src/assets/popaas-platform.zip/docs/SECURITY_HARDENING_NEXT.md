# Security hardening (v1.4 additions)

This version adds:
- SBOM generation + keyless signing workflow (Syft + Cosign)
- Optional OPA policy-as-code for centralized auth decisions
- Optional service-to-service mTLS reference using step-ca + Envoy

Recommended next steps for production:
1. Enable OPA checks for high-risk routes (admin, billing, vault).
2. Run Tempo + Loki + Prometheus as private services.
3. Generate real mTLS certs using step-cli (do not use placeholders).
4. Configure allowlists and rate limits at ingress.
