# Backup & Disaster Recovery (All stages)

POPaaS supports:
- Postgres backups (pg_dump/pg_restore)
- Qdrant snapshots (per collection)
- OpenSearch snapshots (repo-based)

## Stage guidance
### Dev
- Use `scripts/backup_postgres.sh` and `scripts/restore_postgres.sh`
- Use `scripts/snapshot_qdrant.sh`
- OpenSearch: use filesystem snapshots if you must (see scripts/snapshot_opensearch.md)

### Staging
- Nightly backups to durable storage
- Restore drills weekly
- Snapshot retention: 14–30 days

### Production
- Postgres: PITR (WAL archiving) + daily full backups
- OpenSearch: snapshots to S3-compatible storage
- Qdrant: scheduled snapshots + off-host replication
- Quarterly full restore drill to a clean environment

## Minimum RPO/RTO targets
- RPO: 15–60 minutes (with PITR), 24h without
- RTO: 1–4 hours depending on infra

## Immutable audit logs
Ensure audit logs are shipped to Loki (or external WORM storage) for tamper resistance.
