# POPaaS Option B: Qdrant + OpenSearch

This build uses:
- **Postgres** for relational state
- **Redis** for queues/rate limits/cache
- **Qdrant** for vector search (embeddings, similarity)
- **OpenSearch** for text search/log analytics and faceted queries

## Local run
1. `docker compose -f docker-compose.optionB.yml up -d`
2. Set `.env` values based on `.env.example`
3. Start services (see `docs/DEPLOYMENT_LOCAL.md`)

## Production notes
OpenSearch can be memory hungry. If running on a small instance, consider:
- lowering JVM heap (`OPENSEARCH_JAVA_OPTS`)
- using Postgres full-text + Qdrant only, if needed.
