#!/usr/bin/env bash
set -euo pipefail
STAMP=$(date -u +"%Y%m%dT%H%M%SZ")
OUT_DIR=${1:-backups/postgres}
mkdir -p "$OUT_DIR"
PG_URL=${DATABASE_URL:-postgresql://popaas:popaas_password_change_me@localhost:5432/popaas}
FILE="$OUT_DIR/popaas_${STAMP}.dump"
echo "Backing up Postgres to $FILE"
pg_dump "$PG_URL" -Fc -f "$FILE"
echo "OK"
