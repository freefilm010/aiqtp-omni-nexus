#!/usr/bin/env bash
set -euo pipefail
STAMP=$(date -u +"%Y%m%dT%H%M%SZ")
OUT_DIR=${1:-backups/qdrant}
mkdir -p "$OUT_DIR"
QDRANT_URL=${QDRANT_URL:-http://localhost:6333}
COLLECTION=${2:-popaas}
FILE="$OUT_DIR/${COLLECTION}_${STAMP}.snapshot"
echo "Requesting Qdrant snapshot for collection=$COLLECTION"
curl -sS -X POST "$QDRANT_URL/collections/$COLLECTION/snapshots" | tee /tmp/qdrant_snapshot.json >/dev/null
SNAP_NAME=$(python - <<'PY'
import json
d=json.load(open("/tmp/qdrant_snapshot.json"))
print(d.get("result",{}).get("name",""))
PY
)
if [ -z "$SNAP_NAME" ]; then
  echo "Could not determine snapshot name"; exit 1
fi
echo "Downloading snapshot $SNAP_NAME"
curl -sS "$QDRANT_URL/collections/$COLLECTION/snapshots/$SNAP_NAME" -o "$FILE"
echo "Saved $FILE"
