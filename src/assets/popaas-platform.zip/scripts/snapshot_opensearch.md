# OpenSearch snapshots (recommended production approach)

OpenSearch snapshots require a repository (S3, filesystem, etc.).
Because environments differ, POPaaS provides a **runbook** instead of hardcoding credentials.

## Minimal (filesystem repo) example (dev only)
1. Configure `path.repo` in OpenSearch container (requires custom image/config).
2. Register repository:
   POST /_snapshot/popaas_repo
   { "type": "fs", "settings": { "location": "/usr/share/opensearch/snapshots" } }
3. Create snapshot:
   PUT /_snapshot/popaas_repo/snap_YYYYMMDD?wait_for_completion=true
4. Restore snapshot similarly.

See docs/DR_BACKUP.md for production-ready guidance.
