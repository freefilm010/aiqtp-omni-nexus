#!/usr/bin/env bash
set -euo pipefail
FILE=${1:?Usage: restore_postgres.sh <dumpfile>}
PG_URL=${DATABASE_URL:-postgresql://popaas:popaas_password_change_me@localhost:5432/popaas}
echo "Restoring Postgres from $FILE"
pg_restore --clean --if-exists -d "$PG_URL" "$FILE"
echo "OK"
