# Scripts

After extracting on Linux/macOS, you may need:
- `chmod +x scripts/*.sh`

Scripts:
- backup_postgres.sh
- restore_postgres.sh
- snapshot_qdrant.sh
