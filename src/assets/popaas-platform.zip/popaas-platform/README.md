# POPaaS — Platform of Platforms as a Service

POPaaS is a private-first, production-grade "platform of platforms" built as a monorepo with:
- **Client Dashboard** (Next.js)
- **Admin Command Center** (Next.js)
- Modular backend services (FastAPI) for auth, orchestration, intelligence, monetization, vault, trust.

## Quick start (local)
### 1) Backend (all services)
Each service can run independently. Start with Auth + Vault + Intelligence:
```bash
cd services/auth-service && python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt && uvicorn app.main:app --reload --port 8001
cd ../vault-service && python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt && uvicorn app.main:app --reload --port 8005
cd ../intelligence-engine && python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt && uvicorn app.main:app --reload --port 8003
```

### 2) Frontend
```bash
cd apps/client-dashboard && npm i && npm run dev
cd ../admin-command-center && npm i && npm run dev
```

## Deploy
See `infra/render.yaml` and `docs/DEPLOYMENT_RENDER.md`.


## Added modules (v1.1)
- Redis-backed job queue (RQ)
- Agent worker service
- Vision Engine (ONNX MobileNetV2)
- Currency Engine (free FX rates)
- Security + account integration docs
