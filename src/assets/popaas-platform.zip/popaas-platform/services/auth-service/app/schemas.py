from pydantic import BaseModel, EmailStr

class RegisterIn(BaseModel):
  email: EmailStr
  password: str
  role: str = "user"

class LoginIn(BaseModel):
  email: EmailStr
  password: str

class UserOut(BaseModel):
  id: str
  email: EmailStr
  role: str
  org_id: str | None
  is_active: bool
