from fastapi import FastAPI, Depends, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import uuid

from _shared.db import Base, engine, get_db
from _shared.security import hash_password, verify_password, create_access_token, decode_token
from .models import User
from .schemas import RegisterIn, LoginIn, UserOut

Base.metadata.create_all(bind=engine)

app = FastAPI(title="POPaaS Auth Service", version="1.0.0")

app.add_middleware(
  CORSMiddleware,
  allow_origins=["*"],
  allow_credentials=True,
  allow_methods=["*"],
  allow_headers=["*"],
)

@app.get("/health")
def health():
  return {"ok": True, "service": "auth-service"}

@app.post("/auth/register", response_model=UserOut)
def register(payload: RegisterIn, db: Session = Depends(get_db)):
  existing = db.query(User).filter(User.email == payload.email).first()
  if existing:
    raise HTTPException(status_code=409, detail="Email already registered")
  user = User(
    id=str(uuid.uuid4()),
    email=payload.email,
    password_hash=hash_password(payload.password),
    role=payload.role,
  )
  db.add(user)
  db.commit()
  db.refresh(user)
  return UserOut(id=user.id, email=user.email, role=user.role, org_id=user.org_id, is_active=user.is_active)

@app.post("/auth/login")
def login(payload: LoginIn, response: Response, db: Session = Depends(get_db)):
  user = db.query(User).filter(User.email == payload.email).first()
  if not user or not user.is_active:
    raise HTTPException(status_code=401, detail="Invalid credentials")
  if not verify_password(payload.password, user.password_hash):
    raise HTTPException(status_code=401, detail="Invalid credentials")
  token = create_access_token(sub=user.id, role=user.role, org_id=user.org_id)
  # set cookies for Next.js middleware use
  response.set_cookie("POPAAS_TOKEN", token, httponly=True, samesite="lax")
  response.set_cookie("POPAAS_ROLE", user.role, httponly=False, samesite="lax")
  return {"access_token": token, "token_type": "bearer", "user": {"id": user.id, "email": user.email, "role": user.role}}

@app.get("/auth/me", response_model=UserOut)
def me(token: str, db: Session = Depends(get_db)):
  try:
    claims = decode_token(token)
  except Exception:
    raise HTTPException(status_code=401, detail="Invalid token")
  user = db.query(User).filter(User.id == claims.get("sub")).first()
  if not user:
    raise HTTPException(status_code=404, detail="User not found")
  return UserOut(id=user.id, email=user.email, role=user.role, org_id=user.org_id, is_active=user.is_active)
