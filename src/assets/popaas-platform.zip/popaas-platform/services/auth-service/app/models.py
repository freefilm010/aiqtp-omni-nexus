from sqlalchemy import Column, String, DateTime, Boolean
from sqlalchemy.sql import func
from _shared.db import Base

class User(Base):
  __tablename__ = "users"
  id = Column(String, primary_key=True)
  email = Column(String, unique=True, index=True, nullable=False)
  password_hash = Column(String, nullable=False)
  role = Column(String, default="user", nullable=False)
  org_id = Column(String, nullable=True)
  is_active = Column(Boolean, default=True, nullable=False)
  created_at = Column(DateTime(timezone=True), server_default=func.now())
