from rq import Worker
from _shared.queue import get_queue, get_redis
from _shared.logging import get_logger

log = get_logger("agent-worker")

if __name__ == "__main__":
  q = get_queue("agents")
  w = Worker([q], connection=get_redis())
  log.info("agent-worker started; listening on 'agents' queue")
  w.work(with_scheduler=True)
