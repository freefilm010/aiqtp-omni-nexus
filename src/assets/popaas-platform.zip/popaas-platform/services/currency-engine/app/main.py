from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, Optional
import time, json
import requests

from _shared.logging import get_logger

log = get_logger("currency-engine")
app = FastAPI(title="POPaaS Currency Engine", version="1.0.0")

CACHE_TTL = int(__import__("os").getenv("FX_CACHE_TTL", "300"))
_cache: Dict[str, Any] = {"ts": 0, "base": None, "rates": None}

class RatesOut(BaseModel):
  base: str
  asof: float
  rates: Dict[str, float]

@app.get("/health")
def health():
  return {"ok": True, "service": "currency-engine"}

@app.get("/fx/rates", response_model=RatesOut)
def rates(base: str = "USD"):
  now = time.time()
  if _cache["rates"] is not None and _cache["base"] == base and (now - _cache["ts"]) < CACHE_TTL:
    return RatesOut(base=base, asof=_cache["ts"], rates=_cache["rates"])

  # exchangerate.host is free and does not require an API key.
  url = f"https://api.exchangerate.host/latest?base={base}"
  try:
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    data = r.json()
    rates = {k: float(v) for k,v in (data.get("rates") or {}).items()}
  except Exception as e:
    log.info(f"fx fetch failed: {e}")
    raise HTTPException(status_code=502, detail="FX provider unavailable")

  _cache.update({"ts": now, "base": base, "rates": rates})
  return RatesOut(base=base, asof=now, rates=rates)
