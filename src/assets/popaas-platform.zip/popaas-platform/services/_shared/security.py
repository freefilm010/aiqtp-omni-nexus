import datetime as dt
from passlib.context import CryptContext
from jose import jwt
from .config import settings

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str) -> str:
  return pwd_context.hash(password)

def verify_password(password: str, password_hash: str) -> bool:
  return pwd_context.verify(password, password_hash)

def create_access_token(sub: str, role: str, org_id: str | None = None) -> str:
  now = dt.datetime.utcnow()
  exp = now + dt.timedelta(minutes=settings.jwt_exp_minutes)
  payload = {
    "iss": settings.jwt_issuer,
    "sub": sub,
    "role": role,
    "org_id": org_id,
    "iat": int(now.timestamp()),
    "exp": int(exp.timestamp()),
  }
  return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")

def decode_token(token: str) -> dict:
  return jwt.decode(token, settings.jwt_secret, algorithms=["HS256"], issuer=settings.jwt_issuer)
