import os
from pydantic import BaseModel

class Settings(BaseModel):
  # Core
  database_url: str = os.getenv("DATABASE_URL", "sqlite:///./popaas.db")
  redis_url: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")

  # Auth
  jwt_secret: str = os.getenv("JWT_SECRET", "change-me-in-prod")
  jwt_issuer: str = os.getenv("JWT_ISSUER", "popaas")
  jwt_exp_minutes: int = int(os.getenv("JWT_EXP_MINUTES", "60"))

  # Vault
  vault_fernet_key: str = os.getenv("VAULT_FERNET_KEY", "")

  # Ops
  environment: str = os.getenv("ENVIRONMENT", "development")  # development|staging|production

settings = Settings()
