from rq import Queue
from redis import Redis
from .config import settings

def get_redis() -> Redis:
  return Redis.from_url(settings.redis_url)

def get_queue(name: str = "default") -> Queue:
  return Queue(name, connection=get_redis())
