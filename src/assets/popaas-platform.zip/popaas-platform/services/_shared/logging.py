import json
import logging
import os
import sys
from datetime import datetime
from .config import settings

class JsonFormatter(logging.Formatter):
  def format(self, record: logging.LogRecord) -> str:
    payload = {
      "ts": datetime.utcnow().isoformat() + "Z",
      "level": record.levelname,
      "logger": record.name,
      "msg": record.getMessage(),
    }
    if record.exc_info:
      payload["exc_info"] = self.formatException(record.exc_info)
    # Optional extras
    for key in ("service", "request_id", "user_id", "org_id"):
      if hasattr(record, key):
        payload[key] = getattr(record, key)
    return json.dumps(payload, ensure_ascii=False)

def get_logger(service_name: str) -> logging.Logger:
  logger = logging.getLogger(service_name)
  if logger.handlers:
    return logger
  logger.setLevel(logging.INFO if settings.environment == "production" else logging.DEBUG)
  handler = logging.StreamHandler(sys.stdout)
  handler.setFormatter(JsonFormatter())
  logger.addHandler(handler)
  logger.propagate = False
  return logger
