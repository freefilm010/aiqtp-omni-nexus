from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Any, Dict, List, Optional
import time, uuid

from _shared.queue import get_queue
from _shared.logging import get_logger
from . import __init__  # noqa
from .tasks import run_agent_task

log = get_logger("agent-orchestrator")

app = FastAPI(title="POPaaS Agent Orchestrator", version="1.1.0")

@app.get("/health")
def health():
  return {"ok": True, "service": "agent-orchestrator"}

# Built-in agents (extensible via marketplace later)
AGENTS = [
  {"id": "summarize", "name": "Summarizer", "description": "Summarizes a text payload."},
  {"id": "classify", "name": "Classifier", "description": "Assigns a simple category label."},
  {"id": "extract", "name": "Extractor", "description": "Extracts key fields from structured text."},
]

class RunIn(BaseModel):
  agent_id: str
  input: Dict[str, Any]

class RunOut(BaseModel):
  run_id: str
  agent_id: str
  started_at: float
  finished_at: float
  output: Dict[str, Any]

class EnqueueOut(BaseModel):
  job_id: str

class JobStatusOut(BaseModel):
  job_id: str
  status: str
  result: Optional[Dict[str, Any]] = None
  error: Optional[str] = None

@app.get("/agents", response_model=List[Dict[str, Any]])
def list_agents():
  return AGENTS

@app.post("/run", response_model=RunOut)
def run_sync(payload: RunIn):
  result = run_agent_task(payload.agent_id, payload.input)
  return RunOut(**result)

@app.post("/jobs/enqueue", response_model=EnqueueOut)
def enqueue(payload: RunIn):
  q = get_queue("agents")
  job = q.enqueue(run_agent_task, payload.agent_id, payload.input, job_timeout=180)
  log.info(f"enqueued job {job.id} for agent {payload.agent_id}")
  return EnqueueOut(job_id=job.id)

@app.get("/jobs/{job_id}", response_model=JobStatusOut)
def job_status(job_id: str):
  q = get_queue("agents")
  job = q.fetch_job(job_id)
  if not job:
    raise HTTPException(status_code=404, detail="Job not found")
  status = job.get_status()
  if status == "failed":
    return JobStatusOut(job_id=job.id, status=status, error=str(job.exc_info)[:2000] if job.exc_info else "failed")
  if job.is_finished:
    return JobStatusOut(job_id=job.id, status=status, result=job.result)
  return JobStatusOut(job_id=job.id, status=status)
