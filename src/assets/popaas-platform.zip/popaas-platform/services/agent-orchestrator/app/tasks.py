import time, uuid
from typing import Any, Dict

def run_agent_task(agent_id: str, payload: Dict[str, Any]) -> Dict[str, Any]:
  started = time.time()
  run_id = str(uuid.uuid4())

  # Extremely simple built-in behaviors (no external APIs required).
  out: Dict[str, Any] = {}
  if agent_id == "summarize":
    txt = str(payload.get("text",""))
    out = {"summary": (txt[:200] + ("..." if len(txt) > 200 else ""))}
  elif agent_id == "classify":
    txt = str(payload.get("text","")).lower()
    label = "general"
    if "bitcoin" in txt or "blockchain" in txt:
      label = "crypto"
    elif "tax" in txt or "irs" in txt:
      label = "finance"
    out = {"label": label}
  elif agent_id == "extract":
    txt = str(payload.get("text",""))
    lines = [l.strip() for l in txt.splitlines() if l.strip()]
    out = {"lines": lines[:50], "line_count": len(lines)}
  else:
    out = {"error": "Unknown agent_id"}

  finished = time.time()
  return {"run_id": run_id, "agent_id": agent_id, "started_at": started, "finished_at": finished, "output": out}
