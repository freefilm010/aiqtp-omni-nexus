from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
import math

app = FastAPI(title="POPaaS Trust Service", version="1.0.0")

@app.get("/health")
def health():
  return {"ok": True, "service": "trust-service"}

class Event(BaseModel):
  kind: str
  severity: int  # 1-10
  recency_days: int

class ScoreIn(BaseModel):
  events: List[Event]

@app.post("/trust/score")
def score(payload: ScoreIn):
  # Simple, explainable trust scoring: decays with severity and recency.
  base = 100.0
  penalty = 0.0
  for e in payload.events:
    decay = math.exp(-e.recency_days / 30.0)
    penalty += e.severity * 2.5 * decay
  score = max(0.0, base - penalty)
  return {
    "score": round(score, 2),
    "explain": "Score starts at 100, penalties decay over time; higher severity penalizes more.",
    "penalty": round(penalty, 2),
  }
