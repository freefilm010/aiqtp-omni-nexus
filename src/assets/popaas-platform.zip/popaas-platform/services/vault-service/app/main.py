from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from _shared.config import settings
from cryptography.fernet import Fernet
import os, io, uuid, pathlib

app = FastAPI(title="POPaaS Vault Service", version="1.0.0")

DATA_DIR = pathlib.Path(os.getenv("VAULT_DATA_DIR", "./vault_data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

def _fernet():
  key = settings.vault_fernet_key
  if not key:
    # generate deterministic dev key file if not present
    kf = DATA_DIR / ".dev_fernet_key"
    if kf.exists():
      key = kf.read_text().strip()
    else:
      key = Fernet.generate_key().decode("utf-8")
      kf.write_text(key)
  return Fernet(key.encode("utf-8"))

class Item(BaseModel):
  id: str
  filename: str
  size_bytes: int

@app.get("/health")
def health():
  return {"ok": True, "service": "vault-service"}

@app.post("/vault/upload", response_model=Item)
async def upload(file: UploadFile = File(...)):
  data = await file.read()
  fid = str(uuid.uuid4())
  f = _fernet()
  enc = f.encrypt(data)
  path = DATA_DIR / f"{fid}.bin"
  path.write_bytes(enc)
  meta = DATA_DIR / f"{fid}.json"
  meta.write_text(f"{file.filename}\n{len(data)}")
  return Item(id=fid, filename=file.filename, size_bytes=len(data))

@app.get("/vault/list", response_model=list[Item])
def list_items():
  items=[]
  for meta in DATA_DIR.glob("*.json"):
    fid = meta.stem
    lines = meta.read_text().splitlines()
    if len(lines) >= 2:
      filename = lines[0]
      size = int(lines[1])
    else:
      filename = "unknown"
      size = 0
    items.append(Item(id=fid, filename=filename, size_bytes=size))
  return sorted(items, key=lambda x: x.filename.lower())

@app.get("/vault/download/{item_id}")
def download(item_id: str):
  path = DATA_DIR / f"{item_id}.bin"
  meta = DATA_DIR / f"{item_id}.json"
  if not path.exists() or not meta.exists():
    raise HTTPException(status_code=404, detail="Not found")
  filename = meta.read_text().splitlines()[0]
  f = _fernet()
  data = f.decrypt(path.read_bytes())
  return StreamingResponse(io.BytesIO(data), media_type="application/octet-stream",
                           headers={"Content-Disposition": f'attachment; filename="{filename}"'})
