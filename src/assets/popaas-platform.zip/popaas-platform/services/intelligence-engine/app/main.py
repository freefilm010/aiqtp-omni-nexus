from fastapi import FastAPI
from pydantic import BaseModel, Field
import networkx as nx
from typing import List, Dict, Any, Optional

app = FastAPI(title="POPaaS Intelligence Engine", version="1.0.0")

@app.get("/health")
def health():
  return {"ok": True, "service": "intelligence-engine"}

class TxIO(BaseModel):
  address: str
  value_sats: int

class Tx(BaseModel):
  txid: str
  inputs: List[TxIO]
  outputs: List[TxIO]
  timestamp: Optional[int] = None

class AnalyzeIn(BaseModel):
  # Provide a set of transactions for graph-based pattern detection
  transactions: List[Tx]
  focus_txid: Optional[str] = None

def detect_coinjoin(tx: Tx) -> Dict[str, Any]:
  # Simple, explainable heuristic:
  # CoinJoin-like transactions often have many inputs and many outputs, with multiple equal-sized outputs.
  outs = [o.value_sats for o in tx.outputs]
  if len(tx.inputs) >= 5 and len(tx.outputs) >= 5:
    counts = {}
    for v in outs:
      counts[v] = counts.get(v, 0) + 1
    max_same = max(counts.values()) if counts else 0
    if max_same >= 3:
      return {"match": True, "reason": "Many inputs/outputs with repeated equal-sized outputs", "equal_output_value": max(counts, key=lambda k: counts[k])}
  return {"match": False}

def detect_peel_chain(transactions: List[Tx]) -> Dict[str, Any]:
  # Peel chain: repeated pattern where one output continues with slightly reduced value and one "payment" output splits off.
  # Here we detect a candidate chain by following the largest output's address across txs.
  # This is a heuristic, not attribution.
  tx_by_id = {t.txid: t for t in transactions}
  # Build address->txs index for outputs
  out_index = {}
  for t in transactions:
    for o in t.outputs:
      out_index.setdefault(o.address, []).append((t.txid, o.value_sats))
  # Find candidate starting points: txs with exactly 2 outputs and one output much larger than the other
  candidates = []
  for t in transactions:
    if len(t.outputs) == 2:
      a, b = t.outputs[0].value_sats, t.outputs[1].value_sats
      hi, lo = (a, b) if a >= b else (b, a)
      if hi >= lo * 5:
        candidates.append(t)
  best = {"match": False, "chain": [], "reason": "No strong peel-chain candidates"}
  for start in candidates:
    # follow largest output address up to depth 6
    chain = [start.txid]
    current = start
    for _ in range(6):
      # choose largest output address
      big = max(current.outputs, key=lambda o: o.value_sats)
      nxt_candidates = out_index.get(big.address, [])
      # pick a tx where this address appears as an input next (we don't have input refs), so approximate by next tx emitting from same address
      # Since we only have address/value, we follow by subsequent tx where that address is in inputs.
      nxt = None
      for tid, _v in nxt_candidates:
        if tid == current.txid:
          continue
      # better: search transactions where big.address appears in inputs
      for t in transactions:
        if t.txid in chain:
          continue
        if any(i.address == big.address for i in t.inputs):
          nxt = t
          break
      if not nxt:
        break
      if len(nxt.outputs) != 2:
        break
      chain.append(nxt.txid)
      current = nxt
    if len(chain) >= 3:
      best = {"match": True, "chain": chain, "reason": "Repeated 2-output pattern following dominant output address"}
      break
  return best

@app.get("/blockchain/patterns")
def patterns():
  return {
    "foundational": ["UTXO model", "Scripts", "Mempool/fees", "Change outputs"],
    "common_patterns": ["Peel chain", "CoinJoin-like", "Consolidation", "Fan-out", "Dusting"],
    "core_techniques": ["Graph traversal", "Address clustering (heuristic)", "Temporal analysis"],
    "advanced_methods": ["Probabilistic attribution", "Entity labeling (user-supplied)"],
    "visualization": ["Flow graphs", "Timelines", "Report export"],
    "limits_best_practices": ["Avoid false certainty", "Track confidence", "Document assumptions"],
  }

@app.post("/blockchain/analyze")
def analyze(payload: AnalyzeIn):
  txs = payload.transactions
  focus = None
  if payload.focus_txid:
    focus = next((t for t in txs if t.txid == payload.focus_txid), None)

  # Build a simple address flow graph for visualization payloads
  G = nx.DiGraph()
  for t in txs:
    for i in t.inputs:
      G.add_node(i.address)
    for o in t.outputs:
      G.add_node(o.address)
    for i in t.inputs:
      for o in t.outputs:
        G.add_edge(i.address, o.address, txid=t.txid)

  coinjoin_hits = []
  for t in txs:
    cj = detect_coinjoin(t)
    if cj.get("match"):
      coinjoin_hits.append({"txid": t.txid, **cj})

  peel = detect_peel_chain(txs)

  result = {
    "summary": {
      "transactions": len(txs),
      "addresses": G.number_of_nodes(),
      "flows": G.number_of_edges(),
    },
    "patterns": {
      "coinjoin_like": coinjoin_hits,
      "peel_chain": peel,
    },
    "focus": focus.model_dump() if focus else None,
    "confidence_notes": [
      "Heuristics are probabilistic; results are indicators, not identity claims.",
      "Provide more context (timestamps, UTXO references) for higher confidence.",
    ],
    "graph": {
      "nodes": list(G.nodes())[:5000],
      "edges": [{"source": u, "target": v, "txid": d.get("txid")} for u, v, d in list(G.edges(data=True))[:20000]],
    },
  }
  return result
