from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
import uuid

app = FastAPI(title="POPaaS Monetization Engine", version="1.0.0")

@app.get("/health")
def health():
  return {"ok": True, "service": "monetization-engine"}

class Plan(BaseModel):
  id: str
  name: str
  price_usd_month: int
  included_runs: int
  overage_usd_per_100: int

PLANS = [
  Plan(id="starter", name="Starter", price_usd_month=19, included_runs=200, overage_usd_per_100=5),
  Plan(id="pro", name="Pro", price_usd_month=79, included_runs=2000, overage_usd_per_100=3),
  Plan(id="enterprise", name="Enterprise", price_usd_month=499, included_runs=20000, overage_usd_per_100=1),
]

class SubscribeIn(BaseModel):
  user_id: str
  plan_id: str

class SubscribeOut(BaseModel):
  subscription_id: str
  user_id: str
  plan_id: str
  status: str

@app.get("/billing/plans", response_model=List[Plan])
def list_plans():
  return PLANS

@app.post("/billing/subscribe", response_model=SubscribeOut)
def subscribe(payload: SubscribeIn):
  if payload.plan_id not in {p.id for p in PLANS}:
    return SubscribeOut(subscription_id="", user_id=payload.user_id, plan_id=payload.plan_id, status="invalid_plan")
  return SubscribeOut(subscription_id=str(uuid.uuid4()), user_id=payload.user_id, plan_id=payload.plan_id, status="active")
