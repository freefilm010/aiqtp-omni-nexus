from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any
import io, os, hashlib, urllib.request
import numpy as np
from PIL import Image
import onnxruntime as ort

from _shared.logging import get_logger

log = get_logger("vision-engine")
app = FastAPI(title="POPaaS Vision Engine", version="1.0.0")

MODEL_URL = "https://github.com/onnx/models/raw/main/validated/vision/classification/mobilenet/model/mobilenetv2-7.onnx"
LABELS_URL = "https://raw.githubusercontent.com/pytorch/hub/master/imagenet_classes.txt"
CACHE_DIR = os.getenv("VISION_CACHE_DIR", "/tmp/popaas_vision")
os.makedirs(CACHE_DIR, exist_ok=True)
MODEL_PATH = os.path.join(CACHE_DIR, "mobilenetv2-7.onnx")
LABELS_PATH = os.path.join(CACHE_DIR, "imagenet_classes.txt")

def _download_if_needed(url: str, path: str):
  if os.path.exists(path) and os.path.getsize(path) > 0:
    return
  log.info(f"downloading {url} -> {path}")
  urllib.request.urlretrieve(url, path)

def _load_labels() -> List[str]:
  _download_if_needed(LABELS_URL, LABELS_PATH)
  with open(LABELS_PATH, "r", encoding="utf-8") as f:
    return [l.strip() for l in f.readlines() if l.strip()]

def _preprocess(img: Image.Image) -> np.ndarray:
  img = img.convert("RGB").resize((224,224))
  arr = np.array(img).astype(np.float32) / 255.0
  mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
  std = np.array([0.229, 0.224, 0.225], dtype=np.float32)
  arr = (arr - mean) / std
  arr = np.transpose(arr, (2,0,1))
  arr = np.expand_dims(arr, 0)
  return arr

_session = None
_labels = None

def _get_session():
  global _session
  if _session is None:
    _download_if_needed(MODEL_URL, MODEL_PATH)
    _session = ort.InferenceSession(MODEL_PATH, providers=["CPUExecutionProvider"])
  return _session

def _get_labels():
  global _labels
  if _labels is None:
    _labels = _load_labels()
  return _labels

class ClassifyOut(BaseModel):
  sha256: str
  topk: List[Dict[str, Any]]

@app.get("/health")
def health():
  return {"ok": True, "service": "vision-engine"}

@app.post("/vision/classify", response_model=ClassifyOut)
async def classify(file: UploadFile = File(...), k: int = 5):
  data = await file.read()
  if not data:
    raise HTTPException(status_code=400, detail="Empty file")
  sha = hashlib.sha256(data).hexdigest()
  img = Image.open(io.BytesIO(data))
  x = _preprocess(img)

  sess = _get_session()
  labels = _get_labels()
  input_name = sess.get_inputs()[0].name
  logits = sess.run(None, {input_name: x})[0].squeeze()
  probs = np.exp(logits) / np.sum(np.exp(logits))
  idx = probs.argsort()[-k:][::-1]
  top = [{"label": labels[int(i)] if int(i) < len(labels) else f"class_{int(i)}", "prob": float(probs[int(i)])} for i in idx]
  return ClassifyOut(sha256=sha, topk=top)
