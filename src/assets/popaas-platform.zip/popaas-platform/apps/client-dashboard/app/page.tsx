"use client";

import { useState } from "react";

export default function Home() {
  const [repo, setRepo] = useState("");
  const [status, setStatus] = useState<string | null>(null);

  async function trigger() {
    setStatus("Dispatching workflow...");
    const res = await fetch("/api/dispatch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ repo }),
    });
    const data = await res.json();
    setStatus(data.ok ? "Workflow dispatched! Check your GitHub Actions." : `Error: ${data.error}`);
  }

  return (
    <main style={{ maxWidth: 760, margin: "0 auto" }}>
      <h1>POPaaS Client Dashboard Starter</h1>
      <p>Enter a GitHub repo (owner/name) and trigger the POPaaS Client Dashboard workflow.</p>
      <div style={{ display: "flex", gap: 8 }}>
        <input
          placeholder="owner/name (leave empty to use GITHUB_REPO)"
          value={repo}
          onChange={(e) => setRepo(e.target.value)}
          style={{ flex: 1, padding: 8, borderRadius: 8, border: "1px solid #ddd" }}
        />
        <button onClick={trigger} style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #ccc", background: "#f5f5f5" }}>
          Run Evolution
        </button>
      </div>
      {status && <p style={{ marginTop: 12 }}>{status}</p>}
      <hr style={{ margin: "24px 0" }} />
      <h2>What it does</h2>
      <ol>
        <li>Dispatches a GitHub Actions workflow in the target repo.</li>
        <li>The workflow runs tests, summarizes failures, and asks the LLM to propose a patch.</li>
        <li>It applies the patch, re-runs tests, and repeats up to N iterations.</li>
        <li>Changes are pushed to a branch and opened as a PR for review.</li>
      </ol>
    </main>
  );
}
