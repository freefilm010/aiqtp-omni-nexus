export default function Overview() {
  return (
    <main className="p-8 space-y-4">
      <h2 className="text-2xl font-semibold">System Overview</h2>
      <ul className="list-disc pl-6 space-y-1 text-sm">
        <li>Service health checks (auth, orchestrator, intelligence, monetization, vault, trust)</li>
        <li>Global kill-switches and rate limits</li>
        <li>Cost and confidence ledgers</li>
        <li>Immutable audit log review</li>
      </ul>
      <p className="text-sm opacity-80">
        This UI is wired to POPaaS APIs via server routes under <code>/api/admin</code>.
      </p>
    </main>
  );
}
