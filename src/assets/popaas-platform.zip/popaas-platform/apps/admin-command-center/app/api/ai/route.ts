import { NextResponse } from "next/server";
import { z } from "zod";
import OpenAI from "openai";

const Body = z.object({
  prompt: z.string().min(1),
});

export async function POST(req: Request) {
  try {
    const json = await req.json();
    const { prompt } = Body.parse(json);

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const model = process.env.OPENAI_MODEL || "gpt-4o-mini";

    const resp = await client.chat.completions.create({
      model,
      messages: [
        { role: "system", content: "You are Software Architect GPT. Be concise and concrete." },
        { role: "user", content: prompt },
      ],
    });

    const text = resp.choices[0]?.message?.content || "";
    return NextResponse.json({ ok: true, text });
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || String(err) }, { status: 500 });
  }
}
