import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const repo = (body?.repo || process.env.GITHUB_REPO || "").trim();
    if (!repo) {
      return NextResponse.json({ ok: false, error: "Missing repo. Provide body.repo or set GITHUB_REPO." }, { status: 400 });
    }
    const token = process.env.GITHUB_TOKEN;
    if (!token) {
      return NextResponse.json({ ok: false, error: "Server missing GITHUB_TOKEN." }, { status: 500 });
    }

    // Trigger workflow_dispatch on ai-evolution.yml
    const [owner, name] = repo.split("/");
    const url = `https://api.github.com/repos/${owner}/${name}/actions/workflows/ai-evolution.yml/dispatches`;
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28"
      },
      body: JSON.stringify({ ref: "main", inputs: {} })
    });

    if (!res.ok) {
      const text = await res.text();
      return NextResponse.json({ ok: false, error: `GitHub API error ${res.status}: ${text}` }, { status: 500 });
    }

    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || String(err) }, { status: 500 });
  }
}
