import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center p-8">
      <div className="max-w-2xl w-full space-y-6">
        <h1 className="text-3xl font-bold">POPaaS Admin Command Center</h1>
        <p className="text-sm opacity-80">
          Root/admin-only console. Use this to govern services, users, routing, pricing, and audit logs.
        </p>
        <div className="flex gap-3 flex-wrap">
          <Link className="px-4 py-2 rounded bg-black text-white" href="/admin/overview">Admin Overview</Link>
          <Link className="px-4 py-2 rounded border" href="/admin/users">Users</Link>
          <Link className="px-4 py-2 rounded border" href="/admin/services">Services</Link>
          <Link className="px-4 py-2 rounded border" href="/admin/audit">Audit Log</Link>
          <Link className="px-4 py-2 rounded border" href="/admin/routing">Model Routing</Link>
          <Link className="px-4 py-2 rounded border" href="/admin/billing">Billing</Link>
        </div>
      </div>
    </main>
  );
}
