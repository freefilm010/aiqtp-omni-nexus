import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

// Minimal RBAC gate: protect /admin routes using POPAAS_ROLE cookie (set by auth-service).
// In production you should validate JWT server-side; this is still functional and blocks non-admin.
export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (pathname.startsWith("/admin")) {
    const role = req.cookies.get("POPAAS_ROLE")?.value || "";
    if (role !== "admin" && role !== "root") {
      const url = req.nextUrl.clone();
      url.pathname = "/";
      return NextResponse.redirect(url);
    }
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*"],
};
