# AI Evolution Starter (Next.js 16 + Vercel)

A Vercel-friendly Next.js 16 starter that includes:
- A minimal UI to trigger an "AI evolution" workflow against a GitHub repo
- An API route that dispatches a GitHub Actions workflow
- A Node script (`scripts/ai-evolve.mjs`) that loops over **review → test → analyze → improve** (configurable to 100 iterations)
- Sample tests with Vitest
- `vercel.json` and a **Deploy with Vercel** button

## One‑Click: Deploy with Vercel

> First push this project to **your** GitHub account, then click:

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=REPLACE_WITH_YOUR_REPO_URL)

Replace `REPLACE_WITH_YOUR_REPO_URL` with your repo URL (for example, `https://github.com/yourname/ai-evolution-starter`).

Vercel will automatically set up the project. Add these Environment Variables in the Vercel dashboard:

- `OPENAI_API_KEY` – your LLM key
- `GITHUB_TOKEN` – a PAT with `repo` and `workflow` scope
- `GITHUB_REPO` – the repo to evolve (e.g., `yourname/ai-evolution-starter`)

## Local dev

```bash
npm i
cp .env.example .env
npm run dev
```

Open http://localhost:3000.

## Run the evolution loop locally

```bash
npm run evolve
```

Config via env:
- `OPENAI_MODEL` (default `gpt-4o-mini`)
- `EVOLVE_MAX_ITERS` (default `100`)

## GitHub Actions

This repo includes two workflows:

- `.github/workflows/ci.yml` – install, build, and test
- `.github/workflows/ai-evolution.yml` – the evolution loop (dispatch with the API or from Actions tab)

## Security & Limits

- The evolution loop uses a GitHub token to create branches and PRs; never expose it in the browser.
- Vercel functions are short‑lived; heavy compute (e.g., running tests) happens inside GitHub Actions.
- All generated patches are committed on dedicated `ai/evolve-*` branches and opened as PRs for review.

## License

MIT
