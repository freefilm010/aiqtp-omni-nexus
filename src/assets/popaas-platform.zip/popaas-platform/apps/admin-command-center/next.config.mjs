/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    // Next.js 16 recommends Turbopack by default for dev; no special flags required
  }
};
export default nextConfig;
