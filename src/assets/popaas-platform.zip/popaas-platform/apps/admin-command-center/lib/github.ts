import { Octokit } from "@octokit/rest";
import fs from "node:fs/promises";
import child_process from "node:child_process";
import { promisify } from "node:util";

const exec = promisify(child_process.exec);

export async function run(cmd: string, cwd?: string) {
  const { stdout, stderr } = await exec(cmd, { cwd });
  if (stderr && !/warning/i.test(stderr)) {
    console.error(stderr);
  }
  return stdout.trim();
}

export async function prepareWorktree(repo: string, token?: string) {
  const [owner, name] = repo.split("/");
  const dir = `.work/${owner}-${name}-${Date.now()}`;
  await fs.mkdir(dir, { recursive: true });
  const auth = token ? `https://${token}:x-oauth-basic@github.com/${owner}/${name}.git` : `https://github.com/${owner}/${name}.git`;
  await run(`git clone --depth=1 ${auth} ${dir}`);
  await run(`git checkout -b ai/evolve-${Date.now()}`, dir);
  return dir;
}

export function makeOctokit(token: string) {
  return new Octokit({ auth: token });
}
