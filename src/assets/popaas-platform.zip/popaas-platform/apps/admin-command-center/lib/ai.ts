import OpenAI from "openai";

export async function suggestPatch(instructions: string, diffContext: string, model = process.env.OPENAI_MODEL || "gpt-4o-mini") {
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const completion = await client.chat.completions.create({
    model,
    messages: [
      { role: "system", content: "You are a senior software engineer. Propose minimal, safe patches as unified diffs." },
      { role: "user", content: `Context:\n${diffContext}\n\nGoal:\n${instructions}\n\nConstraints: Keep changes minimal, runnable, and tested. Output only a unified diff patch starting with ---/+++.` },
    ],
    temperature: 0.2,
  });
  return completion.choices[0]?.message?.content || "";
}
