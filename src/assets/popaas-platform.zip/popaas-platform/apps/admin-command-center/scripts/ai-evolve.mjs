import { fileURLToPath } from "node:url";
import path from "node:path";
import fs from "node:fs/promises";
import { run, prepareWorktree, makeOctokit } from "../lib/github.js";
import OpenAI from "openai";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const {
  OPENAI_API_KEY,
  OPENAI_MODEL = "gpt-4o-mini",
  GITHUB_TOKEN,
  GITHUB_REPO,
  EVOLVE_MAX_ITERS = "100",
} = process.env;

if (!GITHUB_REPO) {
  console.error("Missing GITHUB_REPO");
  process.exit(1);
}
if (!GITHUB_TOKEN) {
  console.error("Missing GITHUB_TOKEN");
  process.exit(1);
}
if (!OPENAI_API_KEY) {
  console.error("Missing OPENAI_API_KEY");
  process.exit(1);
}

const client = new OpenAI({ apiKey: OPENAI_API_KEY });
const octokit = makeOctokit(GITHUB_TOKEN);

function now() { return new Date().toISOString(); }

async function runTests(dir) {
  try {
    await run("npm ci", dir);
    const out = await run("npm test --silent", dir);
    return { ok: true, out };
  } catch (e) {
    return { ok: false, out: String(e) };
  }
}

async function summarize(out) {
  const prompt = [
    { role: "system", content: "Summarize test results. If failing, list top 3 root causes with file hints." },
    { role: "user", content: out.slice(-10000) }
  ];
  const resp = await client.chat.completions.create({ model: OPENAI_MODEL, messages: prompt, temperature: 0.2 });
  return resp.choices[0]?.message?.content ?? "";
}

async function proposePatch(summary, repoDir) {
  // Get a small diff context (git status + recent files)
  const status = await run("git status --porcelain", repoDir);
  const files = await run("git ls-files", repoDir);
  const prompt = [
    { role: "system", content: "Propose a minimal unified diff to improve tests or fix failing tests." },
    { role: "user", content: `Test summary:\n${summary}\n\nRepo files:\n${files.slice(0, 5000)}\n\nConstraints: produce a valid 'git apply -p0' unified diff. Keep changes minimal.` }
  ];
  const resp = await client.chat.completions.create({ model: OPENAI_MODEL, messages: prompt, temperature: 0.2 });
  return resp.choices[0]?.message?.content ?? "";
}

async function applyPatch(patch, repoDir) {
  const patchFile = path.join(repoDir, "patch.diff");
  await fs.writeFile(patchFile, patch, "utf-8");
  try {
    await run(`git apply ${patchFile}`, repoDir);
    return true;
  } catch (e) {
    console.error("Patch failed:", e);
    return false;
  }
}

async function commitAndPush(repoDir, branchName, message) {
  await run("git add -A", repoDir);
  await run(`git commit -m ${JSON.stringify(message)}`, repoDir);
  await run(`git push --set-upstream origin ${branchName}`, repoDir);
}

async function openPullRequest(owner, name, branchName, title, body) {
  const { data: pr } = await octokit.pulls.create({
    owner, repo: name, head: branchName, base: "main", title, body
  });
  return pr.html_url;
}

async function main() {
  const [owner, name] = GITHUB_REPO.split("/");
  const dir = await prepareWorktree(GITHUB_REPO, GITHUB_TOKEN);
  const branch = (await run("git branch --show-current", dir)).trim();

  const maxIters = parseInt(EVOLVE_MAX_ITERS, 10);
  for (let i = 1; i <= maxIters; i++) {
    console.log(`[${now()}] Iteration ${i}/${maxIters}: running tests...`);
    const t = await runTests(dir);
    const summary = await summarize(t.out);
    console.log(summary);

    const allPassing = /\bpassed\b/i.test(t.out) && !/\bfail\b/i.test(t.out);
    if (allPassing) {
      console.log("All tests passing; stopping.");
      break;
    }

    console.log("Proposing patch...");
    const patch = await proposePatch(summary, dir);
    if (!patch || !/^(---|diff --git)/m.test(patch)) {
      console.log("No valid patch produced; stopping.");
      break;
    }

    console.log("Applying patch...");
    const ok = await applyPatch(patch, dir);
    if (!ok) break;

    await commitAndPush(dir, branch, `chore(ai): evolve iteration ${i}`);
  }

  console.log("Opening PR...");
  const prUrl = await openPullRequest(owner, name, branch, "AI Evolution", "Automated improvement loop.");
  console.log("PR:", prUrl);
}

main().catch((e) => { console.error(e); process.exit(1); });
