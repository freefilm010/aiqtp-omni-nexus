# POPaaS Deployment on Render

This repository includes a Render Blueprint at `infra/render.yaml`.

## Steps
1. Push this repo to GitHub.
2. In Render, choose **New > Blueprint** and point to your repo.
3. Set required environment variables for services:
   - `JWT_SECRET` (auth-service)
   - `DATABASE_URL` (optional; defaults to SQLite for dev)
   - `VAULT_FERNET_KEY` (optional; vault will generate a dev key if not set)

## Private-first
For private deployments:
- Put dashboards behind auth (already supported).
- Restrict service access using Render private networking or IP allowlists.
