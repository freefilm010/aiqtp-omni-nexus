# POPaaS Security Model

## Non-negotiables
- POPaaS **never** asks for or stores your email passwords.
- Integrations with Gmail/Google/Microsoft/etc. should be done via **OAuth** (token-based) or service accounts where appropriate.
- All sensitive operations are logged to an append-only audit stream (design target).

## Secrets
Set these as environment variables (Render/Vercel/Local):
- `JWT_SECRET` (required)
- `DATABASE_URL` (Postgres recommended for production)
- `REDIS_URL` (required for job queue)
- `VAULT_FERNET_KEY` (required for encrypted vault)

## Cookies
In production, enforce:
- `Secure` cookies
- `HttpOnly` for auth tokens
- `SameSite=Strict` for admin routes

## Rate limiting
Add per-IP and per-user limits for:
- Auth endpoints
- Job enqueue endpoints
- Upload endpoints

## Evidence & intelligence limitations
Any blockchain or OSINT-style heuristic must output:
- methodology
- confidence
- explicit limitations
- reproducibility info (engine version, parameters)
