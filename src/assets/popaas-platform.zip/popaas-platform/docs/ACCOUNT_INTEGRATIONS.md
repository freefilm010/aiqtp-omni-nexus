# Account Integrations (Gmail, Google, etc.)

POPaaS can integrate with accounts like:
- `1drrey@gmail.com`
- `1drrey@duck.com`

But integrations must be done **safely**:
- **Do not** paste passwords into chat or into POPaaS.
- Use **OAuth** (recommended) or provider-approved app tokens.

## Gmail (recommended path)
1. Create a Google Cloud project.
2. Enable Gmail API.
3. Create OAuth Client ID.
4. Add redirect URLs for your POPaaS deployment.
5. Store OAuth client secrets in Render environment variables.
6. POPaaS stores only **refresh tokens** (encrypted), not passwords.

## Duck.com email
Duck.com is primarily an email alias/forwarding layer; integration depends on the upstream mailbox.
POPaaS can integrate with the upstream provider via OAuth/IMAP if supported.

## Why this is required
It prevents account compromise and keeps POPaaS compliant with provider security rules.
