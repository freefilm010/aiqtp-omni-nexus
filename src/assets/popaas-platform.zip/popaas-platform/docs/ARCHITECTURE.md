# POPaaS Architecture

POPaaS is a monorepo with two web apps and multiple backend services.

## Apps
- `apps/client-dashboard` — client-facing portal
- `apps/admin-command-center` — admin/root console

## Services
- `services/auth-service` — register/login/JWT + role cookies
- `services/agent-orchestrator` — agent catalog + execution
- `services/intelligence-engine` — blockchain pattern recognition (explainable heuristics)
- `services/monetization-engine` — plans + subscriptions
- `services/vault-service` — encrypted file vault (Fernet)
- `services/trust-service` — explainable trust scores

## Security model
- JWT in `POPAAS_TOKEN` cookie for server-side use
- Role in `POPAAS_ROLE` cookie for UX gating
- Admin routes protected by Next.js middleware + server checks
